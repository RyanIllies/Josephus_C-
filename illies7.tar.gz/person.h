#include <string>

struct Person {
	std::string name;
	bool alive;
};

	
