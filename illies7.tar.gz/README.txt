Author: Ryan Illies
Assignment: 7
README file



file             function           description
--------------   -----------------  ----------------------
main.cpp         main               main function

CircularQueue.h	 CirQue class       contains definitions for CirQue 			  (templated)	    class   		                                  

Person.h  	  Person struct     contains definition for person 					    struct


	To write this program I used the basic functions provided to get a basic layout of what the program needed to have. I wrote the basic functions and then started to think on how to combine them. I started on the algorithm after I looked at assignment 6 to refresh.

	The program works very good despite early trouble and the only things I may have concerns about would be the copy constructor and the = operator. 
